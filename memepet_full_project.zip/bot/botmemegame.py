
import asyncio
from telegram import Update, WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, filters
import json
import uuid
import pickle
import os
import signal

# Конфигурация
BOT_TOKEN = "<YOUR_BOT_TOKEN>"
WEB_APP_URL = "https://renathadiullin283.github.io/meme-pet-game/"  # размещённая версия игры

# Пути
DATA_DIR = os.path.expanduser("~/meme_pet_data")
DATA_PATH = os.path.join(DATA_DIR, "users.pkl")
os.makedirs(DATA_DIR, exist_ok=True)

# Загрузка и сохранение
users_db = {}

def save_users():
    try:
        with open(DATA_PATH, 'wb') as f:
            pickle.dump(users_db, f)
        print(f"✅ Сохранено: {len(users_db)} пользователей")
    except Exception as e:
        print(f"❌ Ошибка сохранения: {e}")

def load_users():
    global users_db
    try:
        with open(DATA_PATH, 'rb') as f:
            users_db = pickle.load(f)
        print(f"✅ Загружено: {len(users_db)} пользователей")
    except:
        users_db = {}
        print("⚠️ Создана новая база")

load_users()

# Команда /start
async def start(update: Update, context):
    user_id = update.effective_user.id

    if user_id not in users_db:
        users_db[user_id] = {
            "eggs": {
                "common": 3,
                "rare": 2,
                "legendary": 1
            },
            "meme_coins": 100,
            "inventory": [{"name": "Еда", "type": "food", "count": 3}],
            "pets": []
        }
        save_users()

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🎮 Открыть игру", web_app=WebAppInfo(url=WEB_APP_URL))]
    ])
    await update.message.reply_text("Добро пожаловать в MemePet!", reply_markup=keyboard)

# Приём данных из WebApp
async def handle_webapp_data(update: Update, context):
    user_id = update.effective_user.id

    try:
        data = json.loads(update.effective_message.web_app_data.data)
        action = data.get("action")

        if user_id not in users_db:
            raise ValueError("Сначала запустите команду /start")

        user_data = users_db[user_id]

        if action == "update_data":
            user_data["eggs"] = data.get("eggs", user_data.get("eggs", {}))
            user_data["meme_coins"] = data.get("coins", user_data.get("meme_coins", 0))
            user_data["inventory"] = data.get("inventory", user_data.get("inventory", []))
            user_data["pets"] = data.get("pets", user_data.get("pets", []))
            save_users()
            await update.message.reply_text("✅ Прогресс сохранён!")

        elif action == "sync":
            await update.message.reply_text(json.dumps(user_data))

        elif action == "buy_egg":
            egg_type = data.get("egg_type")
            cost_map = {"common": 20, "rare": 50, "legendary": 100}

            if egg_type not in cost_map:
                raise ValueError("Неизвестный тип яйца")

            cost = cost_map[egg_type]
            if user_data["meme_coins"] < cost:
                await update.message.reply_text("❌ Недостаточно монет!")
            else:
                user_data["meme_coins"] -= cost
                user_data["eggs"].setdefault(egg_type, 0)
                user_data["eggs"][egg_type] += 1
                save_users()
                await update.message.reply_text(f"✅ Куплено яйцо: {egg_type}")

        else:
            await update.message.reply_text("⚠️ Неизвестное действие")

    except Exception as e:
        await update.message.reply_text(f"🚨 Ошибка: {str(e)}")

# Выход с сохранением
def save_on_exit(signum, frame):
    print("\n🔴 Завершение...")
    save_users()
    exit(0)

# Запуск
if __name__ == "__main__":
    signal.signal(signal.SIGINT, save_on_exit)
    signal.signal(signal.SIGTERM, save_on_exit)

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, handle_webapp_data))

    print("🤖 Бот запущен")
    asyncio.run(app.run_polling())
